import java.util.List;
public class Messenger {

  LetterComposite messageFromOrcs() {

    List<Word> words = List.of(
            new Word(List.of(new Letter('W'), new Letter('h'), new Letter('e'), new Letter(
                    'r'), new Letter('e'))),
            new Word(List.of(new Letter('t'), new Letter('h'), new Letter('e'), new Letter(
                    'r'), new Letter('e'))),
            new Word(List.of(new Letter('i'), new Letter('s'))),
            new Word(List.of(new Letter('a'))),
            new Word(List.of(new Letter('w'), new Letter('h'), new Letter('i'), new Letter(
                    'p'))),
            new Word(List.of(new Letter('t'), new Letter('h'), new Letter('e'), new Letter(
                    'r'), new Letter('e'))),
            new Word(List.of(new Letter('i'), new Letter('s'))),
            new Word(List.of(new Letter('a'))),
            new Word(List.of(new Letter('w'), new Letter('a'), new Letter('y'))));

    return new Sentence(words);

  }

  LetterComposite messageFromElves() {

    List<Word> words = List.of(
            new Word(List.of(new Letter('M'), new Letter('u'), new Letter('c'), new Letter('h'))),
            new Word(List.of(new Letter('w'), new Letter('i'), new Letter('n'), new Letter('d'))),
            new Word(List.of(new Letter('p'), new Letter('o'), new Letter('u'), new Letter('r'),
                    new Letter('s'))),
            new Word(List.of(new Letter('f'), new Letter('r'), new Letter('o'), new Letter('m'))),
            new Word(List.of(new Letter('y'), new Letter('o'), new Letter('u'), new Letter('r'))),
            new Word(List.of(new Letter('m'), new Letter('o'), new Letter('u'), new Letter('t'),
                    new Letter('h'))));

    return new Sentence(words);

  }

}
